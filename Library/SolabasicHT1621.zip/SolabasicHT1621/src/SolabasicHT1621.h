#ifndef SOLABASIC_HT1621_H
#define SOLABASIC_HT1621_H

#include <Arduino.h>

class SolabasicHT1621 {
 public:
  static const uint8_t DISPLAY_INPUT  = 1;
  static const uint8_t DISPLAY_OUTPUT = 2;
  static const uint8_t RAM_ADDRESSES  = 32;
  static const uint8_t ELEMENT_COUNT  = 128;

  enum Icon {
    ICON_OUTPUT        = 0,
    ICON_LOAD          = 8,
    ICON_FAULT         = 24,
    ICON_VCA2          = 25,
    ICON_VAC_OUTPUT    = 25,
    ICON_HZ2           = 26,
    ICON_HZ_OUTPUT     = 26,
    ICON_PERCENT       = 27,
    ICON_PERCENT_OUTPUT= 27,
    ICON_LOWER_FRAME   = 28,
    ICON_VCA1          = 29,
    ICON_VAC_INPUT     = 29,
    ICON_HZ1           = 30,
    ICON_HZ_INPUT      = 30,
    ICON_VCC1          = 31,
    ICON_VDC_INPUT     = 31,
    ICON_DC            = 31,
    ICON_BACKUP_MODE   = 41,
    ICON_BALANCE       = 42,
    ICON_BATTERY_FULL  = 43,
    ICON_BATTERY_PM    = 44,
    ICON_LINE_MODE     = 45,
    ICON_AVR           = 46,
    ICON_AC            = 47,
    ICON_ALTERNATING_CURRENT = 47,
    ICON_DECIMAL_1     = 52,
    ICON_BATTERY       = 60,
    ICON_INPUT         = 68
  };

  explicit SolabasicHT1621(uint8_t pinCS = 2,
                           uint8_t pinWR = 4,
                           uint8_t pinData = 5,
                           uint8_t pinReset = 3);

  void begin(bool clearDisplay = true);
  void hardwareReset();
  void lcdPower(bool enabled);

  void clear();
  void fill();
  void setAll(bool enabled);
  void flush();

  bool writeNibble(uint8_t address, uint8_t value);
  uint8_t readNibble(uint8_t address) const;

  bool setRawBit(uint8_t address, uint8_t bit, bool enabled);
  bool toggleRawBit(uint8_t address, uint8_t bit);
  bool getRawBit(uint8_t address, uint8_t bit) const;

  bool setElement(uint8_t element, bool enabled);
  bool toggleElement(uint8_t element);
  bool getElement(uint8_t element) const;

  bool setNumber(uint8_t display, int value, bool leadingZeros = false);
  bool setDigit(uint8_t display, uint8_t digit, int value);
  bool clearDigit(uint8_t display, uint8_t digit);
  bool setSegment(uint8_t display, uint8_t digit,
                  char segment, bool enabled);
  bool toggleSegment(uint8_t display, uint8_t digit, char segment);

  bool setIcon(Icon icon, bool enabled);
  bool toggleIcon(Icon icon);
  bool getIcon(Icon icon) const;
  bool setIconByName(const char *name, bool enabled);
  bool toggleIconByName(const char *name);
  static int16_t iconFromName(const char *name);

  // Unidades y simbolos asociados a cada display.
  bool setUnitHz(uint8_t display, bool enabled);
  bool setUnitVac(uint8_t display, bool enabled);
  bool setUnitVdc(uint8_t display, bool enabled);
  bool setPercent(bool enabled);
  bool setLowerFrame(bool enabled);
  bool setAcIcon(bool enabled);
  bool setDcIcon(bool enabled);

  bool setBarLevel(uint8_t bar, uint8_t level);
  bool setBarSegment(uint8_t bar, uint8_t segment, bool enabled);
  bool toggleBarSegment(uint8_t bar, uint8_t segment);

 private:
  struct AddrBit {
    uint8_t address;
    uint8_t bit;
  };

  uint8_t _pinCS;
  uint8_t _pinWR;
  uint8_t _pinData;
  uint8_t _pinReset;
  uint8_t _shadow[RAM_ADDRESSES];

  static bool validDisplayDigit(uint8_t display, uint8_t digit);
  static int8_t segmentIndex(char segment);
  static void elementToAddrBit(uint8_t element,
                               uint8_t &address, uint8_t &bit);

  void delayBus() const;
  void writePulse();
  void sendBits(uint32_t bits, uint8_t count);
  void command(uint8_t value);
  void writeHardwareNibble(uint8_t address, uint8_t value);
  void writeAddress(uint8_t address);
  void setShadowBit(uint8_t address, uint8_t bit, bool enabled);
  bool setDigitMask(uint8_t display, uint8_t digit, uint8_t mask);
};

#endif
