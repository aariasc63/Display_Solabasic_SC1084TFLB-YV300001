#include "SolabasicHT1621.h"

#include <string.h>

namespace {

struct MapPosition {
  uint8_t address;
  uint8_t bit;
};

// [display 0..1][digit 0..2][segment A..G]
const MapPosition DIGIT_MAP[2][3][7] = {
  {
    // Display 1: INPUT / BATTERY
    { {16,3}, {16,2}, {16,1}, {16,0}, {17,1}, {17,3}, {17,2} },
    { {12,3}, {12,2}, {12,1}, {12,0}, {13,1}, {13,3}, {13,2} },
    { {14,3}, {14,2}, {14,1}, {14,0}, {15,1}, {15,3}, {15,2} }
  },
  {
    // Display 2: OUTPUT / LOAD
    { {1,3}, {1,2}, {1,1}, {1,0}, {0,1}, {0,3}, {0,2} },
    { {3,3}, {3,2}, {3,1}, {3,0}, {2,1}, {2,3}, {2,2} },
    { {5,3}, {5,2}, {5,1}, {5,0}, {4,1}, {4,3}, {4,2} }
  }
};

const uint8_t DIGIT_MASKS[10] = {
  0x3F,  // 0
  0x06,  // 1
  0x5B,  // 2
  0x4F,  // 3
  0x66,  // 4
  0x6D,  // 5
  0x7D,  // 6
  0x07,  // 7
  0x7F,  // 8
  0x6F   // 9
};

// [bar 0..1][segment 0..3]
const uint8_t BAR_ELEMENTS[2][4] = {
  {39, 38, 37, 36},
  {35, 34, 33, 32}
};

struct NamedIcon {
  const char *name;
  uint8_t element;
};

const NamedIcon ICONS[] = {
  {"output",        0},
  {"load",          8},
  {"fault",        24},
  {"vca2",         25},
  {"vac_output",   25},
  {"hz2",          26},
  {"hz_output",    26},
  {"percent",      27},
  {"percentage",   27},
  {"frame",        28},
  {"lower_frame",  28},
  {"marco_inferior",28},
  {"vca1",         29},
  {"vac_input",    29},
  {"hz1",          30},
  {"hz_input",     30},
  {"vcc1",         31},
  {"vdc_input",    31},
  {"dc",           31},
  {"backup",       41},
  {"balance",      42},
  {"battery_full", 43},
  {"battery_pm",   44},
  {"line_mode",    45},
  {"avr",          46},
  {"ac",           47},
  {"alternating_current",47},
  {"corriente_alterna",47},
  {"dp1",          52},
  {"battery",      60},
  {"input",        68}
};

const uint8_t ICON_COUNT = sizeof(ICONS) / sizeof(ICONS[0]);

}  // namespace

SolabasicHT1621::SolabasicHT1621(uint8_t pinCS, uint8_t pinWR,
                                 uint8_t pinData, uint8_t pinReset)
    : _pinCS(pinCS),
      _pinWR(pinWR),
      _pinData(pinData),
      _pinReset(pinReset) {
  memset(_shadow, 0, sizeof(_shadow));
}

void SolabasicHT1621::begin(bool clearDisplay) {
  pinMode(_pinCS, OUTPUT);
  pinMode(_pinWR, OUTPUT);
  pinMode(_pinData, OUTPUT);
  pinMode(_pinReset, OUTPUT);

  digitalWrite(_pinCS, HIGH);
  digitalWrite(_pinWR, LOW);
  digitalWrite(_pinData, LOW);

  hardwareReset();
  command(0x18);  // RC256K
  command(0x01);  // SYS EN
  command(0x29);  // BIAS 1/3, 4 COM
  command(0x03);  // LCD ON
  command(0x0A);  // WDT DIS
  command(0x08);  // TONE OFF

  if (clearDisplay) {
    clear();
  } else {
    flush();
  }
}

void SolabasicHT1621::hardwareReset() {
  digitalWrite(_pinReset, HIGH);
  delay(5);
  digitalWrite(_pinReset, LOW);
  delay(5);
  digitalWrite(_pinReset, HIGH);
  delay(5);
}

void SolabasicHT1621::lcdPower(bool enabled) {
  command(enabled ? 0x03 : 0x02);
}

void SolabasicHT1621::clear() {
  setAll(false);
}

void SolabasicHT1621::fill() {
  setAll(true);
}

void SolabasicHT1621::setAll(bool enabled) {
  memset(_shadow, enabled ? 0x0F : 0x00, sizeof(_shadow));
  flush();
}

void SolabasicHT1621::flush() {
  for (uint8_t address = 0; address < RAM_ADDRESSES; ++address) {
    writeAddress(address);
  }
}

bool SolabasicHT1621::writeNibble(uint8_t address, uint8_t value) {
  if (address >= RAM_ADDRESSES || value > 0x0F) {
    return false;
  }
  _shadow[address] = value;
  writeAddress(address);
  return true;
}

uint8_t SolabasicHT1621::readNibble(uint8_t address) const {
  return address < RAM_ADDRESSES ? _shadow[address] : 0;
}

bool SolabasicHT1621::setRawBit(uint8_t address, uint8_t bit,
                                bool enabled) {
  if (address >= RAM_ADDRESSES || bit > 3) {
    return false;
  }
  setShadowBit(address, bit, enabled);
  writeAddress(address);
  return true;
}

bool SolabasicHT1621::toggleRawBit(uint8_t address, uint8_t bit) {
  if (address >= RAM_ADDRESSES || bit > 3) {
    return false;
  }
  _shadow[address] ^= (uint8_t)(1U << bit);
  writeAddress(address);
  return true;
}

bool SolabasicHT1621::getRawBit(uint8_t address, uint8_t bit) const {
  if (address >= RAM_ADDRESSES || bit > 3) {
    return false;
  }
  return (_shadow[address] & (uint8_t)(1U << bit)) != 0;
}

bool SolabasicHT1621::setElement(uint8_t element, bool enabled) {
  if (element >= ELEMENT_COUNT) {
    return false;
  }
  uint8_t address;
  uint8_t bit;
  elementToAddrBit(element, address, bit);
  return setRawBit(address, bit, enabled);
}

bool SolabasicHT1621::toggleElement(uint8_t element) {
  if (element >= ELEMENT_COUNT) {
    return false;
  }
  uint8_t address;
  uint8_t bit;
  elementToAddrBit(element, address, bit);
  return toggleRawBit(address, bit);
}

bool SolabasicHT1621::getElement(uint8_t element) const {
  if (element >= ELEMENT_COUNT) {
    return false;
  }
  uint8_t address;
  uint8_t bit;
  elementToAddrBit(element, address, bit);
  return getRawBit(address, bit);
}

bool SolabasicHT1621::setNumber(uint8_t display, int value,
                                bool leadingZeros) {
  if (display < 1 || display > 2 || value < 0 || value > 999) {
    return false;
  }

  const uint8_t hundreds = value / 100;
  const uint8_t tens = (value / 10) % 10;
  const uint8_t units = value % 10;

  if (leadingZeros || hundreds != 0) {
    setDigit(display, 1, hundreds);
  } else {
    clearDigit(display, 1);
  }

  if (leadingZeros || hundreds != 0 || tens != 0) {
    setDigit(display, 2, tens);
  } else {
    clearDigit(display, 2);
  }

  setDigit(display, 3, units);
  return true;
}

bool SolabasicHT1621::setDigit(uint8_t display, uint8_t digit, int value) {
  if (!validDisplayDigit(display, digit) || value < 0 || value > 9) {
    return false;
  }
  return setDigitMask(display, digit, DIGIT_MASKS[value]);
}

bool SolabasicHT1621::clearDigit(uint8_t display, uint8_t digit) {
  return setDigitMask(display, digit, 0x00);
}

bool SolabasicHT1621::setSegment(uint8_t display, uint8_t digit,
                                 char segment, bool enabled) {
  if (!validDisplayDigit(display, digit)) {
    return false;
  }
  const int8_t index = segmentIndex(segment);
  if (index < 0) {
    return false;
  }
  const MapPosition &position = DIGIT_MAP[display - 1][digit - 1][index];
  return setRawBit(position.address, position.bit, enabled);
}

bool SolabasicHT1621::toggleSegment(uint8_t display, uint8_t digit,
                                    char segment) {
  if (!validDisplayDigit(display, digit)) {
    return false;
  }
  const int8_t index = segmentIndex(segment);
  if (index < 0) {
    return false;
  }
  const MapPosition &position = DIGIT_MAP[display - 1][digit - 1][index];
  return toggleRawBit(position.address, position.bit);
}

bool SolabasicHT1621::setIcon(Icon icon, bool enabled) {
  return setElement((uint8_t)icon, enabled);
}

bool SolabasicHT1621::toggleIcon(Icon icon) {
  return toggleElement((uint8_t)icon);
}

bool SolabasicHT1621::getIcon(Icon icon) const {
  return getElement((uint8_t)icon);
}

bool SolabasicHT1621::setIconByName(const char *name, bool enabled) {
  const int16_t element = iconFromName(name);
  return element >= 0 && setElement((uint8_t)element, enabled);
}

bool SolabasicHT1621::toggleIconByName(const char *name) {
  const int16_t element = iconFromName(name);
  return element >= 0 && toggleElement((uint8_t)element);
}

int16_t SolabasicHT1621::iconFromName(const char *name) {
  if (name == 0) {
    return -1;
  }
  for (uint8_t index = 0; index < ICON_COUNT; ++index) {
    if (strcmp(name, ICONS[index].name) == 0) {
      return ICONS[index].element;
    }
  }
  return -1;
}

bool SolabasicHT1621::setUnitHz(uint8_t display, bool enabled) {
  if (display == DISPLAY_INPUT) {
    return setIcon(ICON_HZ_INPUT, enabled);
  }
  if (display == DISPLAY_OUTPUT) {
    return setIcon(ICON_HZ_OUTPUT, enabled);
  }
  return false;
}

bool SolabasicHT1621::setUnitVac(uint8_t display, bool enabled) {
  if (display == DISPLAY_INPUT) {
    return setIcon(ICON_VAC_INPUT, enabled);
  }
  if (display == DISPLAY_OUTPUT) {
    return setIcon(ICON_VAC_OUTPUT, enabled);
  }
  return false;
}

bool SolabasicHT1621::setUnitVdc(uint8_t display, bool enabled) {
  if (display != DISPLAY_INPUT) {
    return false;
  }
  return setIcon(ICON_VDC_INPUT, enabled);
}

bool SolabasicHT1621::setPercent(bool enabled) {
  return setIcon(ICON_PERCENT_OUTPUT, enabled);
}

bool SolabasicHT1621::setLowerFrame(bool enabled) {
  return setIcon(ICON_LOWER_FRAME, enabled);
}

bool SolabasicHT1621::setAcIcon(bool enabled) {
  return setIcon(ICON_ALTERNATING_CURRENT, enabled);
}

bool SolabasicHT1621::setDcIcon(bool enabled) {
  return setIcon(ICON_DC, enabled);
}

bool SolabasicHT1621::setBarLevel(uint8_t bar, uint8_t level) {
  if (bar < 1 || bar > 2 || level > 4) {
    return false;
  }
  for (uint8_t segment = 0; segment < 4; ++segment) {
    const uint8_t element = BAR_ELEMENTS[bar - 1][segment];
    uint8_t address;
    uint8_t bit;
    elementToAddrBit(element, address, bit);
    setShadowBit(address, bit, segment < level);
  }
  writeAddress(bar == 1 ? 9 : 8);
  return true;
}

bool SolabasicHT1621::setBarSegment(uint8_t bar, uint8_t segment,
                                    bool enabled) {
  if (bar < 1 || bar > 2 || segment > 3) {
    return false;
  }
  return setElement(BAR_ELEMENTS[bar - 1][segment], enabled);
}

bool SolabasicHT1621::toggleBarSegment(uint8_t bar, uint8_t segment) {
  if (bar < 1 || bar > 2 || segment > 3) {
    return false;
  }
  return toggleElement(BAR_ELEMENTS[bar - 1][segment]);
}

bool SolabasicHT1621::validDisplayDigit(uint8_t display, uint8_t digit) {
  return display >= 1 && display <= 2 && digit >= 1 && digit <= 3;
}

int8_t SolabasicHT1621::segmentIndex(char segment) {
  if (segment >= 'A' && segment <= 'G') {
    segment = (char)(segment - 'A' + 'a');
  }
  return segment >= 'a' && segment <= 'g' ? (int8_t)(segment - 'a') : -1;
}

void SolabasicHT1621::elementToAddrBit(uint8_t element,
                                       uint8_t &address, uint8_t &bit) {
  address = element / 4;
  bit = element % 4;
}

void SolabasicHT1621::delayBus() const {
  delayMicroseconds(3);
}

void SolabasicHT1621::writePulse() {
  digitalWrite(_pinWR, HIGH);
  delayBus();
  digitalWrite(_pinWR, LOW);
  delayBus();
}

void SolabasicHT1621::sendBits(uint32_t bits, uint8_t count) {
  for (int8_t index = (int8_t)count - 1; index >= 0; --index) {
    digitalWrite(_pinData, (bits >> index) & 1U);
    writePulse();
  }
}

void SolabasicHT1621::command(uint8_t value) {
  digitalWrite(_pinCS, LOW);
  sendBits(0b100, 3);
  sendBits(value, 8);
  sendBits(0, 1);
  digitalWrite(_pinCS, HIGH);
}

void SolabasicHT1621::writeHardwareNibble(uint8_t address, uint8_t value) {
  digitalWrite(_pinCS, LOW);
  sendBits(0b101, 3);
  sendBits(address & 0x3F, 6);
  sendBits(value & 0x0F, 4);
  digitalWrite(_pinCS, HIGH);
}

void SolabasicHT1621::writeAddress(uint8_t address) {
  if (address < RAM_ADDRESSES) {
    writeHardwareNibble(address, _shadow[address]);
  }
}

void SolabasicHT1621::setShadowBit(uint8_t address, uint8_t bit,
                                   bool enabled) {
  const uint8_t mask = (uint8_t)(1U << bit);
  if (enabled) {
    _shadow[address] |= mask;
  } else {
    _shadow[address] &= (uint8_t)~mask;
  }
}

bool SolabasicHT1621::setDigitMask(uint8_t display, uint8_t digit,
                                   uint8_t mask) {
  if (!validDisplayDigit(display, digit)) {
    return false;
  }

  const uint8_t displayIndex = display - 1;
  const uint8_t digitIndex = digit - 1;
  for (uint8_t segment = 0; segment < 7; ++segment) {
    const MapPosition &position =
        DIGIT_MAP[displayIndex][digitIndex][segment];
    setShadowBit(position.address, position.bit,
                 ((mask >> segment) & 1U) != 0);
  }

  writeAddress(DIGIT_MAP[displayIndex][digitIndex][0].address);
  writeAddress(DIGIT_MAP[displayIndex][digitIndex][4].address);
  return true;
}
