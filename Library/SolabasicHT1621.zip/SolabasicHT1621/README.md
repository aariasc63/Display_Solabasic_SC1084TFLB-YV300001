# SolabasicHT1621

Biblioteca Arduino para controlar el LCD Solabasic de nobreak basado en
HT1621. El mapa fue obtenido directamente del vidrio LCD probado.

## Conexiones predeterminadas

| LCD | Arduino UNO |
|---|---|
| CS | D2 |
| RESET | D3 |
| WR/CLK | D4 |
| DATA | D5 |
| RDVCC | 5V |
| Backlight + | 5V |
| GND | GND |

Los pines pueden cambiarse desde el constructor:

```cpp
SolabasicHT1621 lcd(pinCS, pinWR, pinData, pinReset);
```

## Instalación

1. En Arduino IDE seleccione **Programa > Incluir librería > Añadir biblioteca .ZIP**.
2. Seleccione `SolabasicHT1621.zip`.
3. Abra **Archivo > Ejemplos > SolabasicHT1621 > ControlPorFunciones**.
4. Cargue el ejemplo al Arduino.

La biblioteca y su ejemplo no usan el monitor serie. Todo el control se realiza
llamando métodos de `SolabasicHT1621` desde `setup()`, `loop()` o las funciones
de su aplicación.

También se incluye **Archivo > Ejemplos > SolabasicHT1621 > TodosLosElementos**,
que prueba automáticamente ambos displays, segmentos A-G, iconos, barras y
todos los elementos E000 a E127 sin usar `Serial`.

## Uso básico

```cpp
#include <SolabasicHT1621.h>

SolabasicHT1621 lcd;

void setup() {
  lcd.begin();

  // Display 1: INPUT / BATTERY
  lcd.setNumber(SolabasicHT1621::DISPLAY_INPUT, 127);

  // Display 2: OUTPUT / LOAD
  lcd.setNumber(SolabasicHT1621::DISPLAY_OUTPUT, 220);

  lcd.setIcon(SolabasicHT1621::ICON_INPUT, true);
  lcd.setIcon(SolabasicHT1621::ICON_OUTPUT, true);
  lcd.setBarLevel(1, 3);
  lcd.setBarLevel(2, 4);
}

void loop() {}
```

## API principal

### Números y segmentos

```cpp
lcd.setNumber(display, valor, cerosIzquierda);
lcd.setDigit(display, digito, valor);
lcd.clearDigit(display, digito);
lcd.setSegment(display, digito, 'a', true);
lcd.toggleSegment(display, digito, 'g');
```

- `display`: 1 para INPUT/BATTERY y 2 para OUTPUT/LOAD.
- `digito`: 1 a 3.
- `valor`: 0 a 999 en `setNumber` y 0 a 9 en `setDigit`.

### Iconos

```cpp
lcd.setIcon(SolabasicHT1621::ICON_FAULT, true);
lcd.setIcon(SolabasicHT1621::ICON_LINE_MODE, true);
lcd.setIconByName("battery", true);
lcd.toggleIconByName("avr");
```

Nombres disponibles: `output`, `load`, `fault`, `vca2`, `hz2`, `percent`,
`frame`, `vca1`, `hz1`, `vcc1`, `backup`, `balance`, `battery_full`,
`battery_pm`, `line_mode`, `avr`, `ac`, `dp1`, `battery` e `input`.

### Unidades, AC/DC y marco inferior

```cpp
lcd.setUnitHz(SolabasicHT1621::DISPLAY_INPUT, true);
lcd.setUnitHz(SolabasicHT1621::DISPLAY_OUTPUT, true);
lcd.setUnitVac(SolabasicHT1621::DISPLAY_INPUT, true);
lcd.setUnitVac(SolabasicHT1621::DISPLAY_OUTPUT, true);
lcd.setUnitVdc(SolabasicHT1621::DISPLAY_INPUT, true); // Vcc/DC, E031
lcd.setPercent(true);                                 // E027
lcd.setLowerFrame(true);                              // E028
lcd.setAcIcon(true);                                  // onda AC, E047
lcd.setDcIcon(true);                                  // alias Vcc/DC, E031
```

También existen los alias `ICON_HZ_INPUT`, `ICON_HZ_OUTPUT`,
`ICON_VAC_INPUT`, `ICON_VAC_OUTPUT`, `ICON_VDC_INPUT`, `ICON_DC`,
`ICON_LOWER_FRAME` e `ICON_ALTERNATING_CURRENT`.

### Barras

```cpp
lcd.setBarLevel(1, 3);          // Nivel 0..4
lcd.setBarSegment(2, 0, true);  // Segmento 0..3
lcd.toggleBarSegment(2, 3);
```

### Control directo

```cpp
lcd.setElement(37, true);       // Elemento E000..E127
lcd.toggleElement(37);
lcd.setRawBit(9, 1, true);      // Dirección 0..31, bit 0..3
lcd.writeNibble(9, 0x0F);
lcd.clear();
lcd.fill();
lcd.lcdPower(false);            // Oculta sin borrar la RAM sombra
lcd.lcdPower(true);
```

## Mapa de displays

| Display | Uso | Dígito 1 | Dígito 2 | Dígito 3 |
|---|---|---:|---:|---:|
| 1 | INPUT/BATTERY | 16/17 | 12/13 | 14/15 |
| 2 | OUTPUT/LOAD | 0/1 | 2/3 | 4/5 |

Los métodos numéricos modifican únicamente A-G y conservan los iconos que
comparten dirección, como INPUT, BATTERY, OUTPUT, LOAD y el punto decimal.
