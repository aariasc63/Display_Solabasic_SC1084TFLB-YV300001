#include <SolabasicHT1621.h>

// Pines predeterminados:
// CS=D2, WR/CLK=D4, DATA=D5, RESET=D3.
SolabasicHT1621 lcd;

uint16_t valorEntrada = 0;
uint8_t nivelBateria = 0;
unsigned long ultimaActualizacion = 0;

void configurarPantallaInicial() {
  // Textos e iconos fijos.
  lcd.setIcon(SolabasicHT1621::ICON_INPUT, true);
  lcd.setIcon(SolabasicHT1621::ICON_BATTERY, true);
  lcd.setIcon(SolabasicHT1621::ICON_OUTPUT, true);
  lcd.setIcon(SolabasicHT1621::ICON_LOAD, true);
  lcd.setIcon(SolabasicHT1621::ICON_LINE_MODE, true);

  // Unidades y simbolos especiales.
  lcd.setUnitVdc(SolabasicHT1621::DISPLAY_INPUT, true);  // Vcc / DC
  lcd.setUnitVac(SolabasicHT1621::DISPLAY_OUTPUT, true); // Vca / AC
  lcd.setLowerFrame(true);
  lcd.setAcIcon(true);

  // Display 1: INPUT / BATTERY.
  lcd.setNumber(SolabasicHT1621::DISPLAY_INPUT, valorEntrada, true);

  // Display 2: OUTPUT / LOAD.
  lcd.setNumber(SolabasicHT1621::DISPLAY_OUTPUT, 220);

  lcd.setBarLevel(1, nivelBateria);
  lcd.setBarLevel(2, 4);
}

void setup() {
  lcd.begin();
  configurarPantallaInicial();
}

void loop() {
  // Ejemplo: actualizar el display y la barra cada segundo.
  if (millis() - ultimaActualizacion >= 1000) {
    ultimaActualizacion = millis();

    valorEntrada++;
    if (valorEntrada > 999) valorEntrada = 0;
    lcd.setNumber(SolabasicHT1621::DISPLAY_INPUT, valorEntrada, true);

    nivelBateria++;
    if (nivelBateria > 4) nivelBateria = 0;
    lcd.setBarLevel(1, nivelBateria);

    // Ejemplo de condición controlada por una variable del programa.
    lcd.setIcon(SolabasicHT1621::ICON_FAULT, valorEntrada > 900);
  }
}
